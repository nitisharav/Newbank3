package com.entity.layer3;

public class FundTransferDto {

	private String fromdate;
	private String todate;
	private String AccountNumber;
	public String getFromdate() {
		return fromdate;
	}
	public void setFromdate(String fromdate) {
		this.fromdate = fromdate;
	}
	public String getTodate() {
		return todate;
	}
	public void setTodate(String todate) {
		this.todate = todate;
	}
	public String getAccountNumber() {
		return AccountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.AccountNumber = accountNumber;
	}
	
	
	
	
	
}
